// LibRC.cpp — R-C 垃圾清理工具的原生（C/C++）删除引擎
//
// 提供三类能力：
//   1. LRC_Delete   — 回收站删除 / 永久删除 / 管理员提权强制删除
//   2. LRC_GetLastError — 取最近一次失败原因
//   3. LRC_WriteWinErr  — 在失败文件同级目录追加 WinERR.log
//
// 编译（MSVC）: cl /LD /EHsc /DLIBRC_EXPORTS LibRC.cpp advapi32.lib shell32.lib user32.lib /FeLibRC.dll
// 编译（MinGW）: g++ -shared -std=c++17 -DLIBRC_EXPORTS LibRC.cpp -o LibRC.dll -ladvapi32 -lshell32 -luser32

#include "LibRC.h"
#include <windows.h>
#include <shellapi.h>
#include <sddl.h>
#include <string>
#include <cwchar>

// ---------------------------------------------------------------------------
// 最近一次错误信息（临界区保护）
// ---------------------------------------------------------------------------
static CRITICAL_SECTION g_cs;
static wchar_t g_lastErr[1024] = { 0 };

static struct InitCS {
    InitCS() { InitializeCriticalSection(&g_cs); }
    ~InitCS() { DeleteCriticalSection(&g_cs); }
} g_initCS;

static void SetLastErr(const std::wstring& s) {
    EnterCriticalSection(&g_cs);
    std::wcsncpy(g_lastErr, s.c_str(), 1023);
    g_lastErr[1023] = 0;
    LeaveCriticalSection(&g_cs);
}

// ---------------------------------------------------------------------------
// 内部辅助
// ---------------------------------------------------------------------------
static bool IsLink(const std::wstring& path) {
    DWORD attr = GetFileAttributesW(path.c_str());
    if (attr == INVALID_FILE_ATTRIBUTES) return false;
    return (attr & FILE_ATTRIBUTE_REPARSE_POINT) != 0;
}

// 启用 SeTakeOwnershipPrivilege / SeRestorePrivilege（需以管理员运行）
static bool EnablePrivileges() {
    HANDLE hToken = NULL;
    if (!OpenProcessToken(GetCurrentProcess(),
                          TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &hToken))
        return false;

    struct LUID { DWORD LowPart; LONG HighPart; };
    struct LUID_AND_ATTRIBUTES { LUID Luid; DWORD Attributes; };
    struct TOKEN_PRIVILEGES { DWORD PrivilegeCount; LUID_AND_ATTRIBUTES Privileges[1]; };

    const wchar_t* names[] = { L"SeTakeOwnershipPrivilege", L"SeRestorePrivilege" };
    for (int i = 0; i < 2; ++i) {
        LUID luid;
        if (LookupPrivilegeValueW(NULL, names[i], &luid)) {
            TOKEN_PRIVILEGES tp;
            tp.PrivilegeCount = 1;
            tp.Privileges[0].Luid = luid;
            tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
            AdjustTokenPrivileges(hToken, FALSE, (PTOKEN_PRIVILEGES)&tp, 0, NULL, NULL);
        }
    }
    CloseHandle(hToken);
    return true;
}

// 移入回收站（可恢复）
static int RecycleDelete(const std::wstring& path) {
    std::wstring from = path + L"\0";            // 双 NULL 结尾
    SHFILEOPSTRUCTW op = { 0 };
    op.wFunc = FO_DELETE;
    op.pFrom = from.c_str();
    op.fFlags = FOF_ALLOWUNDO | FOF_NOCONFIRMATION | FOF_NOERRORUI | FOF_SILENT;
    int res = SHFileOperationW(&op);
    if (res == 0) return 0;
    SetLastErr(L"SHFileOperation 失败: " + std::to_wstring(res));
    return res;
}

// 永久删除
static int PermanentDelete(const std::wstring& path) {
    DWORD attr = GetFileAttributesW(path.c_str());
    if (attr == INVALID_FILE_ATTRIBUTES) {
        SetLastErr(L"文件不存在");
        return 2;
    }
    BOOL ok = (attr & FILE_ATTRIBUTE_DIRECTORY)
                  ? RemoveDirectoryW(path.c_str())
                  : DeleteFileW(path.c_str());
    if (ok) return 0;
    DWORD err = GetLastError();
    SetLastErr(L"删除失败: " + std::to_wstring(err));
    return (int)err;
}

// 提权强制删除：取得所有权 -> 放开 DACL -> 删除
static int ForceDelete(const std::wstring& path) {
    EnablePrivileges();
    PSID adminSid = NULL;
    if (ConvertStringSidToSidW(L"S-1-5-32-544", &adminSid)) {   // Administrators
        // OWNER | DACL；pDacl=NULL 即 NULL DACL（所有人完全控制），文件随即被删除
        SetNamedSecurityInfoW((LPWSTR)path.c_str(), SE_FILE_OBJECT,
                              OWNER_SECURITY_INFORMATION | DACL_SECURITY_INFORMATION,
                              adminSid, NULL, NULL, NULL);
        LocalFree(adminSid);
    }
    return PermanentDelete(path);
}

// ---------------------------------------------------------------------------
// 导出接口
// ---------------------------------------------------------------------------
LIBRC_API int LRC_Delete(const wchar_t* path, int mode) {
    if (!path) { SetLastErr(L"空路径"); return 1; }
    std::wstring p(path);
    if (IsLink(p)) { SetLastErr(L"跳过符号链接"); return 3; }

    if (mode == LRC_MODE_RECYCLE) {
        int r = RecycleDelete(p);
        if (r == 0) return 0;
        return PermanentDelete(p);              // 回收站失败回退永久删除
    } else if (mode == LRC_MODE_PERMANENT) {
        return PermanentDelete(p);
    } else if (mode == LRC_MODE_FORCE) {
        return ForceDelete(p);
    }
    SetLastErr(L"未知删除模式");
    return 4;
}

LIBRC_API void LRC_GetLastError(wchar_t* buf, int bufChars) {
    if (!buf || bufChars <= 0) return;
    EnterCriticalSection(&g_cs);
    std::wcsncpy(buf, g_lastErr, bufChars - 1);
    buf[bufChars - 1] = 0;
    LeaveCriticalSection(&g_cs);
}

LIBRC_API int LRC_WriteWinErr(const wchar_t* filePath, const wchar_t* errMsg) {
    if (!filePath) return 1;

    std::wstring fp(filePath);
    std::wstring dir = fp.substr(0, fp.find_last_of(L"\\/"));
    if (dir.empty()) dir = L".";
    std::wstring logPath = dir + L"\\WinERR.log";

    // 时间戳
    SYSTEMTIME st;
    GetLocalTime(&st);
    wchar_t ts[64];
    swprintf_s(ts, _countof(ts),
               L"[%04d-%02d-%02d %02d:%02d:%02d] ",
               st.wYear, st.wMonth, st.wDay, st.wHour, st.wMinute, st.wSecond);

    std::wstring line = std::wstring(ts) + L"删除失败: " + fp + L" | 错误: " +
                        (errMsg ? std::wstring(errMsg) : L"") + L"\n";

    // 转 UTF-8
    int need = WideCharToMultiByte(CP_UTF8, 0, line.c_str(), -1, NULL, 0, NULL, NULL);
    std::string utf8((size_t)need, '\0');
    WideCharToMultiByte(CP_UTF8, 0, line.c_str(), -1, &utf8[0], need, NULL, NULL);

    HANDLE h = CreateFileW(logPath.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ,
                           NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    if (h == INVALID_HANDLE_VALUE) {
        // 回退：程序所在目录
        wchar_t mod[MAX_PATH] = { 0 };
        GetModuleFileNameW(NULL, mod, MAX_PATH);
        std::wstring md(mod);
        std::wstring mdir = md.substr(0, md.find_last_of(L"\\/"));
        logPath = mdir + L"\\WinERR.log";
        h = CreateFileW(logPath.c_str(), FILE_APPEND_DATA, FILE_SHARE_READ,
                        NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
    }
    if (h == INVALID_HANDLE_VALUE) return 2;

    // 新文件写入 UTF-8 BOM
    LARGE_INTEGER size;
    size.QuadPart = 0;
    GetFileSizeEx(h, &size);
    DWORD written = 0;
    if (size.QuadPart == 0) {
        const char bom[3] = { (char)0xEF, (char)0xBB, (char)0xBF };
        WriteFile(h, bom, 3, &written, NULL);
    }
    WriteFile(h, utf8.c_str(), (DWORD)(utf8.size() - 1), &written, NULL);
    CloseHandle(h);
    return 0;
}
