@echo off
rem ============================================================
rem  Build LibRC.dll with MinGW-w64
rem  Requires: g++ on PATH (e.g. MSYS2 / MinGW-w64 / TDM-GCC)
rem ============================================================
g++ -shared -std=c++17 -O2 -DLIBRC_EXPORTS LibRC.cpp -o LibRC.dll -ladvapi32 -lshell32 -luser32 -lkernel32

if errorlevel 1 (
    echo BUILD FAILED
    exit /b 1
)

echo.
echo Build OK -^> LibRC.dll
echo Copy LibRC.dll next to R-C.pyw (or into the LibRC folder).
echo.
