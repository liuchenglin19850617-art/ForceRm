@echo off
rem ============================================================
rem  Build LibRC.dll with MSVC (Visual Studio)
rem  Run this inside "Developer Command Prompt for VS"
rem ============================================================
cl /LD /EHsc /std:c++17 /DLIBRC_EXPORTS LibRC.cpp advapi32.lib shell32.lib user32.lib kernel32.lib /FeLibRC.dll

if errorlevel 1 (
    echo BUILD FAILED
    exit /b 1
)

echo.
echo Build OK -> LibRC.dll
echo Copy LibRC.dll next to R-C.pyw (or into the LibRC folder).
echo.
