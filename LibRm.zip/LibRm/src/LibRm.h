#ifndef LIBRC_H
#define LIBRC_H

#ifdef _WIN32
#include <windows.h>
#ifdef LIBRC_EXPORTS
#define LIBRC_API __declspec(dllexport)
#else
#define LIBRC_API __declspec(dllimport)
#endif
#else
#define LIBRC_API
#endif

#ifdef __cplusplus
extern "C" {
#endif

/* 删除模式 */
enum LRC_Mode {
    LRC_MODE_RECYCLE  = 0, /* 移入回收站（可恢复） */
    LRC_MODE_PERMANENT = 1, /* 永久删除 */
    LRC_MODE_FORCE     = 2  /* 管理员提权强制删除 */
};

/* 删除单个文件/目录。成功返回 0；失败返回非 0 错误码。 */
LIBRC_API int LRC_Delete(const wchar_t* path, int mode);

/* 获取最近一次错误描述（UTF-16），写入 buf（字符容量 bufChars，含结尾）。 */
LIBRC_API void LRC_GetLastError(wchar_t* buf, int bufChars);

/* 在 filePath 同级目录追加 WinERR.log（失败回退程序目录）。成功返回 0。 */
LIBRC_API int LRC_WriteWinErr(const wchar_t* filePath, const wchar_t* errMsg);

#ifdef __cplusplus
}
#endif

#endif /* LIBRC_H */
